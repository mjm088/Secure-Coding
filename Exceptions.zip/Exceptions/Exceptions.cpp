// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>

// Custom Exception Class
struct custom_exception : public std::exception 
{
    const char* what() const noexcept override
    {
        return "A Custom Exception";
    }
};

bool do_even_more_custom_application_logic()
{
    
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    // Throws a standard exception
    throw std::invalid_argument("Invalid Argument");

    return true;
}
void do_custom_application_logic()
{
    
    std::cout << "Running Custom Application Logic." << std::endl;

    // Exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing
    try 
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }

    catch (std::exception& e) 
    {
        std::cout << "Exception Caught: " << e.what() << std::endl;
    }
    

    // Throws a custom exception derived from std::exception
    // to catch in main
    throw custom_exception();

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Throws an exception to deal with divide by zero errors using
    // a standard C++ defined exception
    if (den == 0) 
    {
        throw std::invalid_argument("Can't Divide by 0 (Undefined)");
    }
    
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    //  Exception handler to capture ONLY the exception thrown
    //  by divide.
    try 
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }

    catch (std::invalid_argument& e) 
    {
        std::cout << "Division Exception Caught: " << e.what() << std::endl;
    }
    
    
}

int main()
{
    try 
    {
        std::cout << "Exceptions Tests!" << std::endl;
        do_division();
        do_custom_application_logic();
    }
    // Catches thrown custom exception
    catch (custom_exception& e) 
    {
        std::cout << "My Custom Exception was Caught." << std::endl;
    }
    // Catches thrown std::exception
    catch (std::exception& e) 
    {
        std::cout << "Exception Caught: " << e.what() << std::endl;
    }
    // Catches any uncaught exceptions
    catch (...) 
    {
        std::cout << "Caught an Exception." << std::endl;
    }
   
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu