// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>   // added for getline
#include <cstring>  // added for strncopy

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;

	const std::string account_number = "CharlieBrown42";
	char user_input[20];

	// 19 available characters discarding the terminator
	const std::size_t MAX_LENGTH = sizeof(user_input) - 1;

	// added a loop till valid input is received
	while (true)
	{
		std::cout << "Enter a value: ";
		// get user input as a string
		std::string input;
		std::getline(std::cin, input);

		// if input is longer than the max allowed
		if (input.length() > MAX_LENGTH)
		{
			// notify user and reprompt them
			std::cout << "You entered too much data.\n  Amount Entered: " << input.length() << "\n  Max allowed: " << MAX_LENGTH << "\n" << std::endl;
			continue;
		}
		
		// if input is valid, copy input to char user_input
		strncpy_s(user_input, sizeof(user_input), input.c_str(), MAX_LENGTH);

		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
		break;
		
	}

}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
